﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WcfWebAppl.ProductServiceReference;

namespace WcfWebAppl
{
    public partial class Default : System.Web.UI.Page
    {


        protected void Button1_Click(object sender, EventArgs e)
        {

            ProductServiceClient spc = new ProductServiceClient();
            this.GridViewProduct.DataSource = spc.GetProductList().Select
                (p => new { p.Id, p.Product_type, p.Prices_per_kilo, p.Availability }).ToList();
            this.GridViewProduct.DataBind();
        }
        }

    }
